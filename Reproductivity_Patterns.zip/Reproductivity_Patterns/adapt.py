"""Matched base, LoRA and full BART summarization on the same held-out documents"""
import argparse,json,time,random,subprocess,sys
from pathlib import Path
import numpy as np
from common import readlines,save,sha,versions,writecsv

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',required=True);p.add_argument('--out',required=True)
    p.add_argument('--corpus',required=True);p.add_argument('--mode',required=True,choices=['base','lora','full'])
    p.add_argument('--seed',type=int,default=42);p.add_argument('--device',default='cpu');p.add_argument('--model',default='facebook/bart-base')
    p.add_argument('--revision',default='main');p.add_argument('--epochs',type=int,default=3);p.add_argument('--lr',type=float,default=1e-4)
    p.add_argument('--rank',type=int,default=8);p.add_argument('--alpha',type=int,default=16);p.add_argument('--dropout',type=float,default=.1)
    p.add_argument('--max-input',type=int,default=512);p.add_argument('--max-target',type=int,default=128);p.add_argument('--accumulate',type=int,default=4)
    p.add_argument('--bertscore-model',default='roberta-large');a=p.parse_args()
    import torch
    from transformers import AutoTokenizer,AutoModelForSeq2SeqLM
    from peft import LoraConfig,get_peft_model,TaskType
    from rouge_score.rouge_scorer import RougeScorer
    from bert_score import score as bertscore
    if not a.model.startswith('facebook/bart'): raise ValueError('This script configures BART q_proj/v_proj.')
    out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
    random.seed(a.seed);np.random.seed(a.seed);torch.manual_seed(a.seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(a.seed)
    rows=[r for r in readlines(a.data) if r['corpus']==a.corpus and r['has_body'] and r['reference']]
    train=[r for r in rows if r['split']=='train'];valid=[r for r in rows if r['split']=='validation'];test=[r for r in rows if r['split']=='test']
    if not train or not valid or not test: raise ValueError('Need body-to-abstract pairs in every partition. Kaggle metadata alone is insufficient; NEVER use the reference abstract as source text.')
    tok=AutoTokenizer.from_pretrained(a.model,revision=a.revision)
    model=AutoModelForSeq2SeqLM.from_pretrained(a.model,revision=a.revision)
    commit=getattr(model.config,'_commit_hash',None)
    if a.mode=='lora':
        model=get_peft_model(model,LoraConfig(task_type=TaskType.SEQ_2_SEQ_LM,r=a.rank,lora_alpha=a.alpha,lora_dropout=a.dropout,bias='none',target_modules=['q_proj','v_proj']))
    model.to(a.device)
    total=sum(p.numel() for p in model.parameters());trainable=sum(p.numel() for p in model.parameters() if p.requires_grad) if a.mode!='base' else 0
    save(out/'config.json',{'args':vars(a),'versions':versions(),'checkpoint_commit':commit,'data_sha256':sha(a.data),
        'trainable_parameters':trainable,'total_parameters':total,'gpu':torch.cuda.get_device_name(0) if a.device.startswith('cuda') else None,
        'timing_scope':'training forward/backward and optimizer only, excluding model load, validation, generation, metrics; separate timings exported',
        'input_policy':'full body, truncated to max_input; title prepended; reference abstract excluded; separate fulltext dataset required',
        'protocol':'fixed epochs and learning rate, no claim of individually optimized methods; same generation and heldout pairs'})
    def batch(r,targets=True):
        x=tok(r['text'],return_tensors='pt',truncation=True,max_length=a.max_input)
        x={k:v.to(a.device) for k,v in x.items()}
        if targets:
            y=tok(text_target=r['reference'],return_tensors='pt',truncation=True,max_length=a.max_target)['input_ids'].to(a.device)
            y[y==tok.pad_token_id]=-100;x['labels']=y
        return x
    def sync():
        if a.device.startswith('cuda'): torch.cuda.synchronize()
    training_seconds=0.;validation=[];log=[]
    if a.device.startswith('cuda'): torch.cuda.reset_peak_memory_stats()
    if a.mode!='base':
        optimizer=torch.optim.AdamW((p for p in model.parameters() if p.requires_grad),lr=a.lr)
        order=list(range(len(train)))
        for epoch in range(a.epochs):
            random.Random(a.seed+epoch).shuffle(order);model.train();optimizer.zero_grad();sync();tic=time.perf_counter();loss_total=0.
            for k,idx in enumerate(order):
                group_start=(k//a.accumulate)*a.accumulate;divisor=min(a.accumulate,len(order)-group_start)
                loss=model(**batch(train[idx])).loss
                loss_total+=float(loss.detach());(loss/divisor).backward()
                if (k+1)%a.accumulate==0 or k+1==len(order):
                    torch.nn.utils.clip_grad_norm_(model.parameters(),1.);optimizer.step();optimizer.zero_grad()
            sync();elapsed=time.perf_counter()-tic;training_seconds+=elapsed
            log.append({'epoch':epoch+1,'train_loss':loss_total/len(train),'seconds':elapsed})
            model.eval()
            with torch.inference_mode(): vloss=sum(float(model(**batch(r)).loss) for r in valid)/len(valid)
            validation.append({'epoch':epoch+1,'loss':vloss})
        model.save_pretrained(out/'checkpoint');tok.save_pretrained(out/'checkpoint')
    train_peak=torch.cuda.max_memory_allocated()/1e9 if a.device.startswith('cuda') else None
    model.eval();pred=[];sync();tic=time.perf_counter()
    with torch.inference_mode():
        for r in test:
            ids=model.generate(**batch(r,False),max_new_tokens=a.max_target,num_beams=4,do_sample=False)
            pred.append(tok.decode(ids[0],skip_special_tokens=True))
    sync();generation_seconds=time.perf_counter()-tic
    scorer=RougeScorer(['rouge1','rougeL'],use_stemmer=True)
    rouge=[scorer.score(r['reference'],s) for r,s in zip(test,pred)]
    bp,br,bf,bs_hash=bertscore(pred,[r['reference'] for r in test],model_type=a.bertscore_model,lang='en',device=a.device,return_hash=True)
    result=[]
    for i,r in enumerate(test):
        result.append({'id':r['id'],'group_id':r['group_id'],'prediction':pred[i],'reference':r['reference'],
          'rouge1':rouge[i]['rouge1'].fmeasure,'rougeL':rouge[i]['rougeL'].fmeasure,'bertscore_f1':float(bf[i]),'factuality_human':''})
    writecsv(out/'predictions.csv',result)
    save(out/'metrics.json',{'mode':a.mode,'corpus':a.corpus,'seed':a.seed,'n_test':len(test),'train_seconds':training_seconds,
      'generation_seconds':generation_seconds,'train_peak_allocated_GB':train_peak,
      'rouge1':float(np.mean([r['rouge1'] for r in result])),'rougeL':float(np.mean([r['rougeL'] for r in result])),
      'bertscore_f1':float(bf.mean()),'bertscore_hash':bs_hash,'train_log':log,'validation_loss':validation,
      'quality_scope':'lexical and semantic similarity, not a factuality guarantee'})
    subprocess.run([sys.executable,'-m','pip','freeze'],stdout=open(out/'environment_freeze.txt','w'),check=True)
    print(out)
if __name__=='__main__': main()
