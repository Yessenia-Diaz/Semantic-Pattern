"""Paired group bootstrap LoRA full"""
import argparse,csv,json
from pathlib import Path
import numpy as np
from common import save
p=argparse.ArgumentParser();p.add_argument('--lora',required=True);p.add_argument('--full',required=True);p.add_argument('--out',required=True)
p.add_argument('--margin',type=float,help='Prospectively justified noninferiority margin on ROUGE-L; never select after looking at results')
p.add_argument('--seed',type=int,default=42);a=p.parse_args()
l=list(csv.DictReader(open(Path(a.lora)/'predictions.csv')));f=list(csv.DictReader(open(Path(a.full)/'predictions.csv')))
l={r['id']:r for r in l};f={r['id']:r for r in f}
if set(l)!=set(f): raise ValueError('Heldout IDs differ')
lc=json.loads((Path(a.lora)/'config.json').read_text());fc=json.loads((Path(a.full)/'config.json').read_text())
for key in ['data_sha256','checkpoint_commit']:
    if lc[key]!=fc[key]: raise ValueError('Unmatched '+key)
for key in ['seed','model','epochs','lr','max_input','max_target','accumulate','bertscore_model']:
    if lc['args'][key]!=fc['args'][key]: raise ValueError('Unmatched setting '+key)
groups={}
for k in sorted(l):
    if l[k]['reference']!=f[k]['reference']: raise ValueError('Unmatched reference '+k)
    groups.setdefault(l[k]['group_id'],[]).append(k)
rng=np.random.default_rng(a.seed);g=list(groups);result={}
for metric in ['rouge1','rougeL','bertscore_f1']:
    delta={k:float(l[k][metric])-float(f[k][metric]) for k in l};boot=[]
    for _ in range(1000):
        sample=[delta[k] for i in rng.choice(len(g),len(g),replace=True) for k in groups[g[i]]];boot.append(float(np.mean(sample)))
    ci=np.quantile(boot,[.025,.975]).tolist();result[metric]={'mean_delta':float(np.mean(list(delta.values()))),'ci95':ci}
if a.margin is not None:
    result['rougeL']['margin']=a.margin;result['rougeL']['noninferiority_supported']=result['rougeL']['ci95'][0]>-a.margin
lm=json.loads((Path(a.lora)/'metrics.json').read_text());fm=json.loads((Path(a.full)/'metrics.json').read_text())
for key in ['train_seconds','train_peak_allocated_GB']:
    if lm[key] is not None and fm[key]: result[key+'_saving_percent']=100*(1-lm[key]/fm[key])
result['interpretation']='Percentile grouped paired CI for a fixed seed. No p-values, Holm test, human factuality or cross-seed inference claimed.'
save(a.out,result);print(a.out)
