"""Controlled P0-P4 evaluation."""
import argparse,copy,json,time,platform,subprocess,sys,hashlib
from collections import Counter
from pathlib import Path
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer,ENGLISH_STOP_WORDS
from sklearn.metrics import f1_score,adjusted_rand_score,normalized_mutual_info_score
from common import readlines,save,sha,digest,writecsv,versions,views,tokens,PROTECTED,PHRASES

def encode(texts,model_name,revision,device,batch):
    import torch
    from transformers import AutoTokenizer,AutoModel
    tok=AutoTokenizer.from_pretrained(model_name,revision=revision)
    enc=AutoModel.from_pretrained(model_name,revision=revision).to(device).eval()
    output=[]
    with torch.inference_mode():
        for text in texts:
            ids=tok(text,add_special_tokens=False)['input_ids'];sums=None;total=0
            for start in range(0,max(1,len(ids)),510*batch):
                chunks=[ids[j:j+510] for j in range(start,min(len(ids),start+510*batch),510)] or [[]]
                features=[tok.prepare_for_model(c,return_special_tokens_mask=True) for c in chunks]
                x=tok.pad(features,padding=True,return_tensors='pt')
                mask=x.pop('special_tokens_mask').to(device)
                x={k:v.to(device) for k,v in x.items()};h=enc(**x).last_hidden_state
                valid=x['attention_mask']*(1-mask);v=(h*valid.unsqueeze(-1)).sum((0,1)).cpu().numpy()
                sums=v if sums is None else sums+v;total+=int(valid.sum())
            output.append(sums/max(1,total))
    commit=getattr(enc.config,'_commit_hash',None)
    del enc
    if torch.cuda.is_available(): torch.cuda.empty_cache()
    return np.asarray(output,dtype=np.float32),commit

def mapping(labels,topics):
    result={}
    for t in sorted(set(topics)-{-1}):
        c=Counter(l for l,x in zip(labels,topics) if x==t and l)
        if c: result[int(t)]=sorted(c,key=lambda k:(-c[k],k))[0]
    return result

def scores(rows,topics,mp,label_key='label'):
    pairs=[(r[label_key],int(t)) for r,t in zip(rows,topics) if r.get(label_key)]
    if not pairs: return {'n_labeled':0,'macro_f1':None}
    y,t=zip(*pairs);pred=[mp.get(x,'__unassigned__') if x!=-1 else '__unassigned__' for x in t]
    classes=sorted(set(y));inside=[i for i,x in enumerate(t) if x!=-1]
    return {'n_labeled':len(y),'n_classes':len(classes),'macro_f1':float(f1_score(y,pred,labels=classes,average='macro',zero_division=0)),
     'macro_f1_assigned':float(f1_score([y[i] for i in inside],[pred[i] for i in inside],labels=classes,average='macro',zero_division=0)) if inside else None,
     'labeled_coverage':len(inside)/len(y),'ari_all':float(adjusted_rand_score(y,t)),
     'nmi_all':float(normalized_mutual_info_score(y,t)),
     'label_policy':'single native label; all labeled test documents, abstentions count as false negatives; classes observed in test',
     'per_class':{c:{'n':sum(z==c for z in y),'f1':float(f1_score(y,pred,labels=[c],average='macro',zero_division=0))} for c in classes}}

def paired_bootstrap(rows,topic_a,mp_a,topic_b,mp_b,iterations=1000,seed=42):
    # Resample duplicate/publication groups, never tune mappings on test labels.
    rng=np.random.default_rng(seed);groups={}
    for i,r in enumerate(rows): groups.setdefault(r['group_id'],[]).append(i)
    keys=list(groups);diff=[]
    classes=sorted(set(r['label'] for r in rows if r['label']))
    for _ in range(iterations):
        ids=[i for k in rng.choice(len(keys),len(keys),replace=True) for i in groups[keys[k]] if rows[i]['label']]
        if not ids: continue
        y=[rows[i]['label'] for i in ids]
        pa=[mp_a.get(int(topic_a[i]),'__unassigned__') if topic_a[i]!=-1 else '__unassigned__' for i in ids]
        pb=[mp_b.get(int(topic_b[i]),'__unassigned__') if topic_b[i]!=-1 else '__unassigned__' for i in ids]
        diff.append(f1_score(y,pa,labels=classes,average='macro',zero_division=0)-f1_score(y,pb,labels=classes,average='macro',zero_division=0))
    return {'contrast':'P3 minus P4 Macro-F1','bootstrap_iterations':iterations,'ci95':np.quantile(diff,[.025,.975]).tolist() if diff else None,
     'note':'Grouped paired percentile interval within one seed, not a multi-seed significance claim; fixed test label universe.'}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--data',required=True);p.add_argument('--out',required=True)
    p.add_argument('--corpus',required=True,choices=['arxiv','pmc_pubmed','s2orc','acl_ocl']);p.add_argument('--seed',type=int,default=42)
    p.add_argument('--device',default='cpu');p.add_argument('--batch',type=int,default=4)
    p.add_argument('--encoder',default='allenai/scibert_scivocab_uncased');p.add_argument('--revision',default='main')
    p.add_argument('--custom-stops',help='One candidate scientific lexical stop word per line; new protocol, not historical inventory')
    p.add_argument('--n-neighbors',type=int,default=10);p.add_argument('--min-cluster-size',type=int,default=8);p.add_argument('--min-samples',type=int,default=8)
    a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
    rows=[r for r in readlines(a.data) if r['corpus']==a.corpus]
    if len(rows)<40: raise ValueError('Need at least 40 eligible source documents; a larger corpus is recommended')
    tr=np.array([i for i,r in enumerate(rows) if r['split']=='train']);va=np.array([i for i,r in enumerate(rows) if r['split']=='validation']);te=np.array([i for i,r in enumerate(rows) if r['split']=='test'])
    if min(len(tr),len(va),len(te))==0: raise ValueError('Empty partition. Increase sample; never move test documents to tune models.')
    custom=set(Path(a.custom_stops).read_text().split()) if a.custom_stops else set()
    english=sorted(ENGLISH_STOP_WORDS);save(out/'stopwords.json',{'provider':'scikit-learn ENGLISH_STOP_WORDS','version':versions()['scikit-learn'],
        'english':english,'protected':sorted(PROTECTED),'phrases':PHRASES,'custom':sorted(custom),'historical':False})
    import torch
    from bertopic import BERTopic
    from bertopic.vectorizers import ClassTfidfTransformer
    from umap import UMAP
    from hdbscan import HDBSCAN
    import random
    random.seed(a.seed);np.random.seed(a.seed);torch.manual_seed(a.seed)
    if torch.cuda.is_available(): torch.cuda.manual_seed_all(a.seed)
    cfg={'args':vars(a),'versions':versions(),'data_sha256':sha(a.data),'platform':platform.platform(),
      'umap':{'n_neighbors':a.n_neighbors,'n_components':5,'min_dist':0.,'metric':'cosine','random_state':a.seed,'transform_seed':a.seed,'n_jobs':1},
      'hdbscan':{'min_cluster_size':a.min_cluster_size,'min_samples':a.min_samples,'metric':'euclidean','cluster_selection_method':'eom','prediction_data':True,'core_dist_n_jobs':1},
      'scope':'prospective explicitly configured rerun; train-only fitting; P0-P3 share clusters; no historical reconstruction',
      'gpu':torch.cuda.get_device_name(0) if torch.cuda.is_available() else None}
    save(out/'config.json',cfg)
    base=None;maps={};assign={};all_results=[];embed0=None;commit=None
    for cond in ['P0','P1','P2','P3','P4']:
        start=time.perf_counter()
        semantic,lexical=zip(*(views(r['text'],cond,english,custom) for r in rows))
        folder=out/cond;folder.mkdir()
        if cond in ['P0','P4']:
            if torch.cuda.is_available(): torch.cuda.reset_peak_memory_stats()
            emb,commit=encode(semantic,a.encoder,a.revision,a.device,a.batch)
            if cond=='P0': embed0=emb
            np.save(folder/'embeddings.npy',emb)
            model=BERTopic(embedding_model=None,umap_model=UMAP(**cfg['umap']),hdbscan_model=HDBSCAN(**cfg['hdbscan']),
                vectorizer_model=CountVectorizer(tokenizer=str.split,token_pattern=None),ctfidf_model=ClassTfidfTransformer(),verbose=True)
            train_topics,_=model.fit_transform([semantic[i] for i in tr],embeddings=emb[tr])
            val_topics,_=model.transform([semantic[i] for i in va],embeddings=emb[va])
            test_topics,_=model.transform([semantic[i] for i in te],embeddings=emb[te])
            cluster_labels=np.empty(len(rows),dtype=int);cluster_labels[tr]=train_topics;cluster_labels[va]=val_topics;cluster_labels[te]=test_topics
            if cond=='P0': base=model;base_labels=cluster_labels.copy()
        else: model=base;emb=embed0;cluster_labels=base_labels.copy()
        # Fit DOCUMENT frequency thresholds before BERTopic aggregates by cluster.
        dfvec=CountVectorizer(tokenizer=str.split,token_pattern=None,lowercase=False,
              min_df=5 if cond in ['P3','P4'] else 1,max_df=.95 if cond in ['P3','P4'] else 1.)
        dfvec.fit([lexical[i] for i in tr]);vocab=dfvec.vocabulary_
        vec=CountVectorizer(tokenizer=str.split,token_pattern=None,lowercase=False,vocabulary=vocab)
        model.update_topics([lexical[i] for i in tr],topics=cluster_labels[tr].tolist(),vectorizer_model=vec,top_n_words=10)
        descriptor={int(t):model.get_topic(int(t)) for t in sorted(set(cluster_labels[tr]) - {-1})}
        mp=mapping([rows[i]['label'] for i in va],cluster_labels[va]);maps[cond]=mp;assign[cond]=cluster_labels.copy()
        metrics=scores([rows[i] for i in te],cluster_labels[te],mp)
        par=mapping([rows[i]['parent_label'] for i in va],cluster_labels[va])
        metrics['parent_resolution']=scores([rows[i] for i in te],cluster_labels[te],par,'parent_label')
        actual_top=[[w for w,wt in v if w] for v in descriptor.values() if v]
        flat=[w for t in actual_top for w in t]
        metrics.update(condition=cond,n_topics=len(descriptor),vocabulary=len(vocab),diversity=len(set(flat))/len(flat) if flat else None,
            outlier_rate_test=float(np.mean(cluster_labels[te]==-1)),wall_seconds=time.perf_counter()-start,
            timing_scope='P0 and P4 include encoding and clustering; P1-P3 only re-description; times are not equal-scope comparisons')
        # Same held-out reference tokenization in ALL conditions. Held-out vocabulary
        # coverage is exported; no silent dropping of unavailable descriptor terms.
        from gensim.corpora import Dictionary
        from gensim.models import CoherenceModel
        reference=[tokens(rows[i]['text']) for i in te];dictionary=Dictionary(reference)
        missing=sorted({w for t in actual_top for w in t if w not in dictionary.token2id})
        metrics['coherence_oov_terms']=missing
        if actual_top and not missing and all(len(t)>1 for t in actual_top):
            for cm in ['c_v','c_npmi']:
                metrics[cm]=float(CoherenceModel(topics=actual_top,texts=reference,dictionary=dictionary,coherence=cm,processes=1).get_coherence())
        else: metrics.update(c_v=None,c_npmi=None,coherence_note='Insufficient held-out support; no substituted or fabricated score')
        metrics['cuda_peak_allocated_gb']=torch.cuda.max_memory_allocated()/1e9 if torch.cuda.is_available() and a.device.startswith('cuda') and cond in ['P0','P4'] else None
        save(folder/'metrics.json',metrics);save(folder/'descriptors.json',descriptor);save(folder/'mapping_validation.json',mp)
        save(folder/'hashes.json',{'semantic_sha256':digest('\n'.join(semantic)),'embeddings_sha256':hashlib.sha256(emb.tobytes()).hexdigest(),'cluster_labels_sha256':digest(cluster_labels.tobytes().hex()),'encoder_commit':commit,'stopwords_sha256':sha(out/'stopwords.json')})
        np.save(folder/'labels.npy',cluster_labels)
        writecsv(folder/'assignments.csv',[{'corpus':r['corpus'],'id':r['id'],'split':r['split'],'group_id':r['group_id'],'label':r['label'],
            'topic':int(cluster_labels[i]),'text_sha256':r['text_sha256'],'title':r['title']} for i,r in enumerate(rows)])
        # Select representative documents by cosine proximity to the TRAINING
        # centroid. This is an automatic representative, not a human topic label.
        representatives=[]
        for t in descriptor:
            inds=[i for i in tr if cluster_labels[i]==t];centroid=emb[inds].mean(0)
            norm=np.linalg.norm(centroid)
            ranked=sorted(inds,key=lambda i:-float(emb[i]@centroid/(max(1e-12,np.linalg.norm(emb[i])*norm))))[:3]
            for i in ranked: representatives.append({'topic':t,'id':rows[i]['id'],'title':rows[i]['title'],'source':rows[i]['source'],
                  'excerpt':rows[i]['text'][:1200],'label':rows[i]['label'],'human_topic_name':''})
        writecsv(folder/'representatives.csv',representatives,['topic','id','title','source','excerpt','label','human_topic_name'])
        # Native HDBSCAN GLOSH is available for fitted TRAIN documents only.
        glosh={int(i):float(s) for i,s in zip(tr,model.hdbscan_model.outlier_scores_)}
        centroids={t:emb[[j for j in tr if cluster_labels[j]==t]].mean(0) for t in descriptor}
        centroids={t:v/max(1e-12,np.linalg.norm(v)) for t,v in centroids.items()}
        candidates=[]
        for i in te:
            if cluster_labels[i]!=-1: continue
            nearest=sorted(descriptor,key=lambda t:-float(emb[i]@centroids[t]))[:2]
            candidates.append({'id':rows[i]['id'],'corpus':a.corpus,'year':rows[i]['year'],'title':rows[i]['title'],
                'excerpt':rows[i]['text'][:1600],'nearest_clusters_candidate':json.dumps(nearest),'audit_cause':'','reviewer_1':'','reviewer_2':'','evidence':'','adjudication':''})
        # Reproducible sample; all outliers remain in assignments.csv.
        candidates.sort(key=lambda r:digest(str(a.seed)+r['id']))
        writecsv(folder/'outlier_audit.csv',candidates[:100],['id','corpus','year','title','excerpt','nearest_clusters_candidate','audit_cause','reviewer_1','reviewer_2','evidence','adjudication'])
        save(folder/'training_glosh.json',{rows[i]['id']:s for i,s in glosh.items()})
        all_results.append(metrics)
    assert all(np.array_equal(assign['P0'],assign[c]) for c in ['P1','P2','P3']), 'P0-P3 cluster invariance violated'
    comp=[]
    for i in te:
        r=rows[i];p3=maps['P3'].get(int(assign['P3'][i]),'__unassigned__');p4=maps['P4'].get(int(assign['P4'][i]),'__unassigned__')
        if assign['P3'][i]!=assign['P4'][i] or p3!=p4:
            comp.append({'id':r['id'],'title':r['title'],'excerpt':r['text'][:1600],'label':r['label'],'P3_topic':int(assign['P3'][i]),'P4_topic':int(assign['P4'][i]),
                'P3_mapped':p3,'P4_mapped':p4,'P3_matches_pseudolabel':bool(r['label'] and p3==r['label']),'P4_matches_pseudolabel':bool(r['label'] and p4==r['label']),
                'P3_semantic':views(r['text'],'P3',english,custom)[0][:1600],'P4_semantic':views(r['text'],'P4',english,custom)[0][:1600],
                'human_assessment':'','warning':'Topic IDs across independent runs are arbitrary; use descriptors and mapping, not numeric equality, to interpret.'})
    writecsv(out/'P3_P4_candidates.csv',comp,['id','title','excerpt','label','P3_topic','P4_topic','P3_mapped','P4_mapped','P3_matches_pseudolabel','P4_matches_pseudolabel','P3_semantic','P4_semantic','human_assessment','warning'])
    save(out/'summary.json',all_results)
    save(out/'P3_P4_bootstrap.json',paired_bootstrap([rows[i] for i in te],assign['P3'][te],maps['P3'],assign['P4'][te],maps['P4'],seed=a.seed))
    subprocess.run([sys.executable,'-m','pip','freeze'],stdout=open(out/'environment_freeze.txt','w'),check=True)
    print(out)
if __name__=='__main__': main()
