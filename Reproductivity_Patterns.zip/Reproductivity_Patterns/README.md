# Reevaluación controlada de MCPR para IJCOPI

Este paquete implementa una NUEVA evaluación. No recupera registros históricos ni reproduce automáticamente los números del manuscrito. Los archivos adjuntos arxiv.json, pmc_pubmed.json, s2orc.json y acl_ocl.json son mapas de campos, no datasets. No se incluyen artículos inventados ni métricas precargadas.

## Qué se verificó en esta entrega

Se verificaron la sintaxis de todos los scripts, normalización de los cuatro esquemas mediante fixtures explícitamente sintéticos, aislamiento de grupos duplicados entre particiones, rechazo de las plantillas del ZIP y reglas P3/P4. No se instalaron ni ejecutaron aquí SciBERT, BERTopic, LoRA o full fine-tuning. El entorno propuesto y las descargas deben validarse al instalar y ejecutar en el equipo de experimentación. CPU disponible; GPU recomendada para corpus grandes. La preparación usa muestreo por prioridad hash y partición por grupos con proporción esperada 70/15/15; NO afirma estratificación ni proporciones exactas.

## Fuentes reales y su alcance

- arXiv: https://www.kaggle.com/datasets/Cornell-University/arxiv. El snapshot contiene id, title, abstract, categories y metadatos. NO contiene secciones completas. La primera categoría se usa como pseudoetiqueta primaria operativa y se documenta; no se afirma anotación temática humana.
- PMC/PubMed: https://pmc.ncbi.nlm.nih.gov/tools/openftlist/. Exportar texto del subconjunto OA mediante sus servicios oficiales; PMC y PubMed no son el mismo recurso. MeSH se obtiene de metadatos PubMed enlazados y de una edición documentada de la jerarquía, NO se infiere de términos del artículo.
- S2ORC: https://github.com/allenai/s2orc y https://aclanthology.org/2020.acl-main.447/. Registrar versión/release. Obtener los shards y metadatos mediante el mecanismo de acceso vigente del proveedor. Un shard de texto puede necesitar unión con metadatos para categoría/abstract; el script no inventa esos campos.
- ACL-OCL: https://huggingface.co/datasets/WINGNUS/ACL-OCL y https://aclanthology.org/2023.emnlp-main.640/. Descargar una revisión fija de los archivos del dataset. Adaptar el mapa de campos a esa versión. Una venue no equivale automáticamente a una etiqueta temática; documentar cómo se produce venue_topic.

Este paquete automatiza la descarga arXiv y la preparación de exportaciones locales de los CUATRO corpus. No automatiza credenciales ni garantiza acceso a releases de los otros tres. No se ha descargado el snapshot completo en esta sesión. Los derechos de reutilización del texto son los de cada fuente/artículo. La selección English-only debe realizarse y registrarse aguas arriba: este paquete no detecta idioma.

## Instalación y arXiv

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -r requirements.txt
# Configurar Kaggle según su CLI; no incluir credenciales en GitHub.
python download_arxiv.py --out data/raw/arxiv
python prepare.py --input arxiv=data/raw/arxiv/arxiv-metadata-oai-snapshot.json --out data/arxiv_100k --sample 100000
python discover.py --data data/arxiv_100k/documents.jsonl --corpus arxiv --out runs/arxiv/42 --seed 42 --device cuda
```

El muestreo recorre el snapshot completo y conserva los menores hashes por corpus, evitando sesgo por tomar las primeras filas. El conjunto resultante puede ser menor que el solicitado tras deduplicar. Inspeccionar provenance.json, excluded.csv y split_manifest.csv. Los CSV de demostración del ZIP anterior no son evidencia arXiv.

## Preparación de los cuatro corpus

Formato recomendado JSONL, un objeto por artículo. También acepta JSON array, CSV y JSONL.gz. Las listas multilabel se dejan sin etiqueta para evitar escoger una clase arbitraria. Si el análisis requiere multilabel, definir una evaluación distinta antes de usarlo. Una etiqueta ausente NO impide el análisis no supervisado.

```bash
python prepare.py --input arxiv=data/raw/arxiv/arxiv-metadata-oai-snapshot.json --input pmc_pubmed=data/raw/pmc.jsonl --input s2orc=data/raw/s2orc.jsonl --input acl_ocl=data/raw/acl.jsonl --out data/four_corpora --sample 100000
python run_all.py --data data/four_corpora/documents.jsonl --out runs --device cuda
```

Opcional: `--mapping pmc_pubmed=mappings/pmc_pubmed.json` y equivalentes, cuando los nombres de campo difieran. Los mapas recibidos se incluyen en mappings/. La plantilla de arXiv describe un export procesado; el lector también reconoce directamente id/abstract/categories de Kaggle. Añadir `parent_label` desde un archivo de jerarquía real con versión documentada si se desea analizar resolución gruesa y fina. No armonizar MeSH y arXiv recortando cadenas sin una correspondencia científica explícita.

Las particiones se asignan por grupo, enlazando DOI, arXiv ID, título normalizado o texto idéntico entre TODOS los corpus antes de dividir. Esto reduce fuga exacta; no detecta por sí solo todos los casi duplicados. Revisar versiones y similitudes de títulos antes de ejecutar. Registrar fechas de descarga y edición taxonómica por fuente.

## Definición operativa de P0 a P4

P0: limpieza mínima en semántica y léxico. P1: inventario sklearn completo solo en léxico. P2: inventario sklearn menos unidades protegidas; `--custom-stops` permite añadir candidatos científicos documentados. Por defecto no se afirma que exista una lista científica histórica. P3: P2 más min_df=5 y max_df=.95 aprendidos en documentos TRAIN individuales. P4: mismo léxico que P3 y eliminación agresiva explícita en la vista semántica, incluidos negadores y conectores protegidos. Es una definición NUEVA, inequívoca, para contrastar la hipótesis.

SciBERT: chunks no solapados de 510 tokens de contenido, media de estados ponderada por cantidad de tokens; no se afirma que SentenceTransformer del ZIP anterior usara esa estrategia. UMAP: 10 vecinos, 5 componentes, min_dist=0, cosine, semilla explícita. HDBSCAN: min_cluster_size=8, min_samples=8, euclidean, eom, prediction_data=True. Estos valores son una configuración inicial declarada; NO son óptimos históricos. Para seleccionar hiperparámetros, usar solo entrenamiento/validación y congelarlos ANTES de examinar test. Los scripts no contienen una búsqueda retrospectiva ni una selección automática que maximice el test.

P0–P3 reutilizan las MISMAS asignaciones. Por construcción, Macro-F1, ARI, NMI y tasa de outliers deben coincidir; pueden cambiar descriptores, vocabulario, coherencia y diversidad. No se fuerza que P3 mejore ni que P4 empeore. `assert` verifica la invariancia. P4 se agrupa independientemente; los números de tópico no son comparables sin correspondencia. TF-IDF documental y c-TF-IDF de tópicos son operaciones distintas. El vocabulario se selecciona sobre documentos antes de agregar por tópico para que min_df realmente cuente artículos.

Se generan por condición config/hashes, stopwords.json con versión, embeddings (P0/P4), labels.npy, assignments.csv, descriptors.json, representatives.csv, outlier_audit.csv, métricas y entorno. ROUGE y BERTScore se reservan al resumen. Macro-F1 usa mapeo muchos-a-uno aprendido en VALIDATION; -1 cuenta como abstención/falso negativo en test, y se informa cobertura. Los tópicos nuevos sin mapeo también se abstienen. Se exportan resultados por clase y, si hay parent_label, por resolución gruesa. No se afirma automáticamente F1 jerárquico ni correspondencia temática real.

La coherencia usa referencia test común a todas las condiciones, sin cambiar ventana por condición, y reporta palabras sin soporte; si falta soporte devuelve null, no un puntaje inventado. Bootstrap pareado por grupo produce IC de la diferencia P3/P4 para cada semilla. No se genera p-value ni se afirma corrección Holm. La agregación entre cinco semillas y análisis de heterogeneidad necesitan un informe posterior con las salidas reales. Para 20k/50k/100k preparar muestras separadas, registrar sus manifiestos y no comparar throughput de alcances distintos. No se implementa DDP ni se afirma reproducir ocho A100.

## Auditoría cualitativa

outlier_audit.csv contiene hasta 100 casos test por corpus/condición seleccionados por hash, texto e IDs. Dos revisores deben codificar: interdisciplinario, artefacto de extracción, tema especializado escaso, candidato emergente con evidencia temporal o indeterminado. Las causas no se asignan automáticamente. Conservar la posibilidad de etiquetas múltiples y resolver desacuerdos. No confundir GLOSH alto (exportado para entrenamiento) con etiqueta -1, ni interpretar outlier como documento inválido.

representatives.csv usa proximidad al centroide del tópico en embeddings. P3_P4_candidates.csv ofrece documentos emparejados, vistas semánticas y correspondencia con pseudoetiqueta; no rotula éxito semántico humano. Un caso P3 acertado/P4 fallido frente a categorías solo se declara tras revisar descriptores y texto. Exportar al artículo 3–5 tópicos por corpus con términos/pesos, ID, pasaje y explicación, y una tabla de outliers con denominadores.

## Comparación LoRA con ajuste completo

Requiere secciones completas como entrada y abstract separado como referencia. Con solo metadatos de Kaggle, el script RECHAZA entrenamiento de resumen: no permite abstract -> el mismo abstract. Conseguir full text autorizado y enlazar por arXiv ID. Se conserva el límite de entrada y se debe discutir pérdida por truncamiento.

```bash
python adapt.py --data data/four_corpora/documents.jsonl --corpus arxiv --mode base --out summary/arxiv/base42 --seed 42 --device cuda
python adapt.py --data data/four_corpora/documents.jsonl --corpus arxiv --mode lora --out summary/arxiv/lora42 --seed 42 --device cuda
python adapt.py --data data/four_corpora/documents.jsonl --corpus arxiv --mode full --out summary/arxiv/full42 --seed 42 --device cuda
python compare_summaries.py --lora summary/arxiv/lora42 --full summary/arxiv/full42 --out summary/arxiv/comparison42.json
```

Repetir por corpus y semillas 42–46. El script usa BART-base, LoRA r=8, alpha=16, dropout=.1, q_proj/v_proj, AdamW lr=1e-4, 3 épocas, batch=1, acumulación=4. Presupuesto fijo explícito, no ajuste óptimo por método. Decodificación igual: beam=4, sin muestreo. La comparación verifica IDs, referencias, checkpoint, parámetros y datos. Reporta ROUGE-1/L, BERTScore, tiempos con alcance definido y memoria asignada. No usa coherencia o F1 de tópicos para valorar LoRA. `--margin` admite un margen de no inferioridad solo si fue justificado ANTES de observar resultados; un p>0.05 no demuestra equivalencia. Añadir evaluación humana de fidelidad.

## Entrega y repositorio

No se modificó GitHub. Después de ejecutar, subir scripts, entorno congelado, manifiestos y salidas permitidas; citar SHA de commit realmente publicado y DOI de release si existe. No publicar texto completo sin revisar licencia. Mantener por separado resultados históricos Springer, tablas propuestas IJCOPI y nuevos resultados calculados. Los archivos metrics.json son salidas calculadas, no plantillas con cifras del manuscrito.
