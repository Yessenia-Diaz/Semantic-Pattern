"""Utilities for prospective controlled re-evaluation"""
import csv, gzip, hashlib, importlib.metadata, json, re, unicodedata
from pathlib import Path

def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

def digest(x): return hashlib.sha256(x.encode()).hexdigest()
def clean(x): return re.sub(r'\s+',' ',unicodedata.normalize('NFKC',str(x or ''))).strip()
def save(path,obj):
    Path(path).parent.mkdir(parents=True,exist_ok=True)
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
def readlines(path):
    op=gzip.open if str(path).endswith('.gz') else open
    with op(path,'rt',encoding='utf-8') as f:
        for line in f:
            if line.strip(): yield json.loads(line)
def writecsv(path,rows,fields=None):
    rows=list(rows)
    if not rows and not fields: return
    with open(path,'w',encoding='utf-8',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields or list(rows[0]));w.writeheader();w.writerows(rows)
def versions():
    names=['numpy','scikit-learn','torch','transformers','bertopic','umap-learn','hdbscan','peft','gensim','rouge-score','bert-score']
    out={}
    for n in names:
        try: out[n]=importlib.metadata.version(n)
        except importlib.metadata.PackageNotFoundError: out[n]=None
    return out

PROTECTED=set('not no nor never neither without cannot but although though however whereas because therefore thus hence nevertheless nonetheless yet despite unless until and or'.split())
PHRASES=['in contrast','in conclusion','for example','as a result','on the other hand','even though']
def tokens(text):
    text=clean(text).lower()
    for x in sorted(PHRASES,key=len,reverse=True): text=re.sub(r'\b'+x+r'\b',x.replace(' ','_'),text)
    return re.findall(r'(?u)\b\w[\w-]*\b',text)
def views(text,condition,english,custom):
    semantic=clean(text)
    if condition=='P4':
        # Deliberately aggressive baseline: explicitly delete protected unigram
        # and multiword units too. Its definition differs from protected P3.
        semantic=' '.join(t for t in tokens(text) if t not in (set(english)|PROTECTED|{p.replace(' ','_') for p in PHRASES}|set(custom)))
    if condition=='P0': stops=set()
    elif condition=='P1': stops=set(english)
    else: stops=(set(english)|set(custom))-PROTECTED
    lexical=' '.join(t for t in tokens(text) if t not in stops)
    return semantic,lexical
