"""Launch the documented five-seed controlled discovery study sequentially."""
import argparse,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--data',required=True);p.add_argument('--out',default='runs')
p.add_argument('--device',default='cpu');p.add_argument('--corpora',nargs='+',default=['arxiv','pmc_pubmed','s2orc','acl_ocl'])
a=p.parse_args()
for corpus in a.corpora:
    for seed in [42,43,44,45,46]:
        subprocess.run([sys.executable,str(Path(__file__).with_name('discover.py')),'--data',a.data,'--out',str(Path(a.out)/corpus/str(seed)),
                        '--corpus',corpus,'--seed',str(seed),'--device',a.device],check=True)
