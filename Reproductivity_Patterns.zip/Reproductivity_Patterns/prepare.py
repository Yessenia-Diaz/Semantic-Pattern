"""Normalize JSONL/JSON/CSV exports for four corpora and preserve provenance."""
import argparse, csv, gzip, heapq, json, re, sys
from collections import Counter
from pathlib import Path
from common import clean,digest,save,sha,writecsv

def records(path):
    op=gzip.open if str(path).endswith('.gz') else open
    with op(path,'rt',encoding='utf-8') as f:
        if str(path).endswith('.csv'): yield from csv.DictReader(f);return
        first=f.read(1);f.seek(0)
        if first=='[': yield from json.load(f)
        else:
            for line in f:
                if line.strip(): yield json.loads(line)

def normalize(r,corpus,mapping,source):
    def field(key,aliases,default=''):
        for name in [mapping.get(key,'')]+aliases:
            if name and r.get(name) is not None: return r[name]
        return default
    ident=field('id',['id','article_id','paper_id','corpusid','acl_id','pmcid'])
    if not ident: raise ValueError('missing stable document id')
    title=clean(field('title',['title']))
    abstract=clean(field('summary',['abstract','abstract_text']))
    sec=field('sections',['sections','body_text'],[])
    if isinstance(sec,list):
        sec='\n'.join(clean(x.get(mapping.get('section_text','text'),'') if isinstance(x,dict) else x) for x in sec)
    elif isinstance(sec,dict): sec='\n'.join(clean(v) for v in sec.values() if isinstance(v,str))
    sec=clean(sec)
    label=field('label',{'arxiv':['primary_category','categories'],'pmc_pubmed':['mesh_top_level'],'s2orc':['field_of_study'],'acl_ocl':['venue_topic']}[corpus])
    if isinstance(label,(list,dict)): label='' # no arbitrary first-label coercion
    label=clean(label)
    if corpus=='arxiv' and 'categories' in r and not r.get('primary_category'): label=clean(r['categories']).split()[0] if clean(r['categories']) else ''
    body=sec or abstract
    text=clean(title+'. '+body)
    if not body: raise ValueError('missing abstract and body text')
    if re.match(r'^doc_\d+_\d+$',str(ident)) and 'Experimental seed group' in text: raise ValueError('demonstration template is not a source article')
    doi=clean(field('doi',['doi'])).lower().replace('https://doi.org/','')
    # Exact normalized-title and DOI links. Fuzzy near-duplicate detection is
    # intentionally not claimed; inspect duplicate candidates before final runs.
    title_key=re.sub(r'\W','',title.lower())
    arxiv=clean(r.get('arxiv_id') or (ident if corpus=='arxiv' else ''))
    return {'corpus':corpus,'id':str(ident),'title':title,'text':text,'reference':abstract if sec else '',
            'has_body':bool(sec),'label':label,'parent_label':clean(r.get('parent_label','')),
            'doi':doi,'arxiv_id':re.sub(r'v\d+$','',arxiv),'title_key':title_key,
            'year':clean(r.get('year') or r.get('update_date','')[:4]),'source':source,'text_sha256':digest(text)}

def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--input',action='append',required=True,help='corpus=/path/export.jsonl[.gz]')
    p.add_argument('--mapping',action='append',default=[],help='corpus=/path/mapping.json')
    p.add_argument('--out',default='data/normalized');p.add_argument('--sample',type=int,default=100000);p.add_argument('--seed',type=int,default=42)
    a=p.parse_args();out=Path(a.out);out.mkdir(parents=True,exist_ok=False)
    maps={k:json.loads(Path(v).read_text()) for k,v in (x.split('=',1) for x in a.mapping)}
    pools={};report=[];excluded=[]
    for arg in a.input:
        corpus,path=arg.split('=',1)
        if corpus not in ['arxiv','pmc_pubmed','s2orc','acl_ocl']: raise ValueError(corpus)
        heap=pools.setdefault(corpus,[]);counts=Counter()
        for i,raw in enumerate(records(path)):
            try:
                row=normalize(raw,corpus,maps.get(corpus,{}),path)
                if len(row['text'].split())<20: raise ValueError('fewer than 20 whitespace words')
            except (ValueError,TypeError,AttributeError) as e:
                counts['excluded']+=1;excluded.append({'corpus':corpus,'source':path,'row':i,'reason':str(e)});continue
            counts['eligible']+=1
            # Deterministic hash-priority sampling across the entire snapshot.
            priority=int(digest(f"{a.seed}:{corpus}:{row['id']}"),16)
            item=(-priority,i,len(report),row)
            if len(heap)<a.sample: heapq.heappush(heap,item)
            elif priority < -heap[0][0]: heapq.heapreplace(heap,item)
        report.append({'corpus':corpus,'path':str(Path(path).resolve()),'sha256':sha(path),'counts':dict(counts)})
    rows=[it[-1] for h in pools.values() for it in h]
    rows.sort(key=lambda r:(r['corpus'],r['id']))
    # Union duplicate identifiers across corpora BEFORE splitting. A document
    # copied into S2ORC and arXiv must not land in different partitions.
    parent=list(range(len(rows)));links={}
    def find(i):
        while parent[i]!=i: parent[i]=parent[parent[i]];i=parent[i]
        return i
    for i,r in enumerate(rows):
        keys=[('doi',r['doi']),('arxiv',r['arxiv_id']),('title',r['title_key']),('text',r['text_sha256']),('id',r['corpus']+':'+r['id'])]
        for k,v in keys:
            if not v: continue
            key=(k,v)
            if key in links: parent[find(i)]=find(links[key])
            else: links[key]=i
    groups={}
    for i,r in enumerate(rows): groups.setdefault(find(i),[]).append(i)
    for inds in groups.values():
        gid=min(rows[i]['text_sha256'] for i in inds);u=int(digest(f'{a.seed}:{gid}')[:16],16)/16**16
        split='train' if u<.7 else ('validation' if u<.85 else 'test')
        for i in inds: rows[i].update(group_id=gid,split=split)
    seen=set();final=[]
    for r in rows:
        key=(r['corpus'],r['group_id'])
        if key in seen: continue
        seen.add(key);final.append(r)
    with open(out/'documents.jsonl','w',encoding='utf-8') as f:
        for r in final: f.write(json.dumps(r,ensure_ascii=False)+'\n')
    writecsv(out/'split_manifest.csv',[{k:r[k] for k in ['corpus','id','group_id','split','text_sha256','label','has_body']} for r in final])
    writecsv(out/'excluded.csv',excluded,['corpus','source','row','reason'])
    save(out/'provenance.json',{'protocol':'prospective grouped hash split, expected 70/15/15; not stratified; exact duplicate links only',
         'seed':a.seed,'sampling':'lowest SHA256 priorities per corpus; not stratified','requested_per_corpus':a.sample,
         'inputs':report,'output_sha256':sha(out/'documents.jsonl'),'counts':dict(Counter((r['corpus']+':'+r['split']) for r in final)),
         'warning':'Use text+body -> abstract for summarization. Abstract-only rows are excluded from summary training to avoid reference leakage. Parent labels must be provided from a documented taxonomy.'})
    if not final: sys.exit('No eligible source documents. Check files; schema JSONs are not datasets.')
    print(f'{len(final)} unique within-corpus documents; inspect {out}/provenance.json')
if __name__=='__main__': main()
