"""Download the Cornell arXiv metadata snapshot through the user's Kaggle CLI."""
import argparse, subprocess, zipfile
from pathlib import Path
from common import save,sha
from datetime import datetime,timezone
p=argparse.ArgumentParser();p.add_argument('--out',default='data/raw/arxiv');a=p.parse_args()
out=Path(a.out);out.mkdir(parents=True,exist_ok=True)
subprocess.run(['kaggle','datasets','download','-d','Cornell-University/arxiv','-p',str(out)],check=True)
z=out/'arxiv.zip'
with zipfile.ZipFile(z) as f:
    matches=[n for n in f.namelist() if n.endswith('arxiv-metadata-oai-snapshot.json')]
    if len(matches)!=1: raise RuntimeError('Snapshot filename changed; inspect archive')
    target=out/'arxiv-metadata-oai-snapshot.json'
    with f.open(matches[0]) as src,open(target,'wb') as dst:
        import shutil
        shutil.copyfileobj(src,dst)
save(out/'download_manifest.json',{'dataset':'Cornell-University/arxiv','retrieved_utc':datetime.now(timezone.utc).isoformat(),
    'sha256_zip':sha(z),'sha256_snapshot':sha(target),'scope':'metadata, title, abstract, categories; NOT structured full text'})
print(target)
