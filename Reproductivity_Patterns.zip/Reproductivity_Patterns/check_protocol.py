"""Checks fixtures"""
import json,subprocess,sys,tempfile,unittest
from pathlib import Path
from sklearn.feature_extraction.text import ENGLISH_STOP_WORDS
from common import views,versions,save
from prepare import normalize
class ProtocolChecks(unittest.TestCase):
    def test_semantic_and_lexical_controls(self):
        text='The treatment did not improve survival; however adverse events decreased.'
        sem=[views(text,c,ENGLISH_STOP_WORDS,set())[0] for c in ['P0','P1','P2','P3']]
        self.assertEqual(len(set(sem)),1)
        p3=views(text,'P3',ENGLISH_STOP_WORDS,set());p4=views(text,'P4',ENGLISH_STOP_WORDS,set())
        self.assertEqual(p3[1],p4[1]);self.assertIn('not',p3[0]);self.assertNotIn('not',p4[0].split())
        self.assertNotIn('however',p4[0].split())
    def test_four_mappings_and_no_reference_leakage(self):
        for corpus,ident in [('arxiv','article_id'),('pmc_pubmed','pmcid'),('s2orc','paper_id'),('acl_ocl','acl_id')]:
            r={ident:'A1','title':'Fixture title','abstract':'Distinct reference abstract','sections':[{'text':'Body without the reference.'}]}
            n=normalize(r,corpus,{},'fixture')
            self.assertTrue(n['has_body']);self.assertNotIn('Distinct reference',n['text']);self.assertEqual(n['reference'],'Distinct reference abstract')
        n=normalize({'id':'1234.56789','title':'Title','abstract':'Only abstract','categories':'cs.CL cs.LG'},'arxiv',{},'fixture')
        self.assertFalse(n['has_body']);self.assertEqual(n['reference'],'');self.assertEqual(n['label'],'cs.CL')
    def test_reject_demonstration(self):
        with self.assertRaises(ValueError):
            normalize({'id':'doc_00_0000','title':'Example','abstract':'Experimental seed group 1.'},'arxiv',{},'fixture')
    def test_global_duplicate_groups_and_determinism(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);paths=[]
            for corpus in ['arxiv','s2orc']:
                p=root/(corpus+'.jsonl');paths.append(p)
                with open(p,'w') as f:
                    for i in range(80):
                        r={'id':str(i),'title':f'Synthetic fixture publication {i}', 'doi':f'10.fixture/{i}',
                         'abstract':' '.join(['fixture']*24)+f' {i}','categories':'cs.CL'}
                        f.write(json.dumps(r)+'\n')
            for k in [1,2]:
                subprocess.run([sys.executable,str(Path(__file__).with_name('prepare.py')),'--input','arxiv='+str(paths[0]),'--input','s2orc='+str(paths[1]),'--out',str(root/str(k))],check=True,capture_output=True)
            aa=(root/'1/documents.jsonl').read_text();bb=(root/'2/documents.jsonl').read_text();self.assertEqual(aa,bb)
            groups={}
            for line in aa.splitlines():
                r=json.loads(line);groups.setdefault(r['group_id'],set()).add(r['split'])
            self.assertEqual(len(groups),80);self.assertTrue(all(len(s)==1 for s in groups.values()))
if __name__=='__main__': unittest.main()
