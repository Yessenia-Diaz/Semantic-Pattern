# Resumen metodológico

Este paquete fue construido a partir del artículo:

Semantic Patterns using Hybrid Clustering based on SciBERT and LoRA

## Metodología recuperada del artículo
- Corpus: subconjunto de entre 2,000 y 4,000 documentos de arXiv.
- Preprocesamiento: normalización, eliminación de duplicados, filtrado básico y segmentación.
- Modelado 1: LDA como baseline probabilístico.
- Modelado 2: BERTopic con embeddings de SciBERT.
- Validación semántica: resumen abstractivo con adaptación LoRA.
- Métricas:
  - Coherence (c_v)
  - Macro F1
  - ROUGE-1
  - ROUGE-L
  - BERTScore

## Resultados reportados
- BERTopic + SciBERT: coherence 0.62, macro F1 0.84
- Estabilidad por corpus:
  - 2000 docs: 0.58 ±0.04
  - 3000 docs: 0.61 ±0.03
  - 4000 docs: 0.62 ±0.02
- Resumen:
  - Base Model: R1 0.36, RL 0.31, BERTScore 0.84
  - Model + LoRA: R1 0.41, RL 0.37, BERTScore 0.88
- Impacto de rango LoRA:
  - r=4: R1 0.39, coherence 0.59
  - r=8: R1 0.41, coherence 0.62
  - r=16: R1 0.42, coherence 0.62

## Qué falta para hacerlo 100% ejecutado
- Descargar un corpus real de arXiv.
- Descargar pesos del modelo `allenai/scibert_scivocab_uncased`.
- Descargar un modelo seq2seq base para resumen.
- Entrenar o adaptar LoRA en GPU.
