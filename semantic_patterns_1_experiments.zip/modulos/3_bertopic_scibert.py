from __future__ import annotations

from pathlib import Path
import pandas as pd

try:
    from bertopic import BERTopic
    from sentence_transformers import SentenceTransformer
except Exception:
    BERTopic = None
    SentenceTransformer = None


def run_bertopic_scibert(texts: list[str], embedding_model_name: str = "allenai/scibert_scivocab_uncased", min_topic_size: int = 8):
    if BERTopic is None or SentenceTransformer is None:
        raise ImportError(
            "BERTopic or sentence-transformers is not installed. "
            "Install dependencies from requirements.txt before running this module."
        )

    embedding_model = SentenceTransformer(embedding_model_name)
    topic_model = BERTopic(embedding_model=embedding_model, min_topic_size=min_topic_size, verbose=True)
    topics, probs = topic_model.fit_transform(texts)
    return topic_model, topics, probs


def export_topic_info(topic_model, output_csv: str | Path) -> None:
    info = topic_model.get_topic_info()
    info.to_csv(output_csv, index=False)
