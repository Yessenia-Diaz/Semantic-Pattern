from __future__ import annotations

import re
from pathlib import Path
import pandas as pd


def normalize_text(text: str) -> str:
    text = str(text).strip()
    text = re.sub(r"\s+", " ", text)
    return text.lower()


def preprocess_dataframe(df: pd.DataFrame) -> pd.DataFrame:
    required = {"title", "abstract"}
    missing = required - set(df.columns)
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    out = df.copy()
    out["title"] = out["title"].map(normalize_text)
    out["abstract"] = out["abstract"].map(normalize_text)
    out["text"] = out["title"] + ". " + out["abstract"]
    out = out.drop_duplicates(subset=["text"]).reset_index(drop=True)
    out["n_tokens"] = out["text"].str.split().str.len()
    out = out[out["n_tokens"] >= 3].reset_index(drop=True)
    return out


def load_and_preprocess(csv_path: str | Path) -> pd.DataFrame:
    df = pd.read_csv(csv_path)
    return preprocess_dataframe(df)


if __name__ == "__main__":
    root = Path(__file__).resolve().parents[1]
    src = root / "datasets" / "arxiv_sample_titles_abstracts.csv"
    dst = root / "resultados" / "preprocessed_dataset.csv"
    df = load_and_preprocess(src)
    dst.parent.mkdir(parents=True, exist_ok=True)
    df.to_csv(dst, index=False)
    print(f"Saved preprocessed dataset to: {dst}")
