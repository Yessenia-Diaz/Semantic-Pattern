from __future__ import annotations

from dataclasses import dataclass
from typing import Iterable

try:
    import torch
    from transformers import AutoTokenizer, AutoModelForSeq2SeqLM
    from peft import LoraConfig, get_peft_model, TaskType
except Exception:
    torch = None
    AutoTokenizer = None
    AutoModelForSeq2SeqLM = None
    LoraConfig = None
    get_peft_model = None
    TaskType = None


@dataclass
class SummarizationArtifacts:
    tokenizer: object
    model: object


def build_model(base_model_name: str = "facebook/bart-base", lora_r: int = 8, lora_alpha: int = 16, lora_dropout: float = 0.1) -> SummarizationArtifacts:
    if AutoTokenizer is None or AutoModelForSeq2SeqLM is None or get_peft_model is None:
        raise ImportError(
            "transformers/peft/torch are not installed. Install requirements.txt before running."
        )

    tokenizer = AutoTokenizer.from_pretrained(base_model_name)
    model = AutoModelForSeq2SeqLM.from_pretrained(base_model_name)

    peft_config = LoraConfig(
        task_type=TaskType.SEQ_2_SEQ_LM,
        r=lora_r,
        lora_alpha=lora_alpha,
        lora_dropout=lora_dropout,
        bias="none",
    )
    model = get_peft_model(model, peft_config)
    return SummarizationArtifacts(tokenizer=tokenizer, model=model)


def summarize_texts(model_artifacts: SummarizationArtifacts, texts: Iterable[str], max_input_length: int = 512, max_target_length: int = 128):
    tokenizer = model_artifacts.tokenizer
    model = model_artifacts.model
    summaries = []

    for text in texts:
        inputs = tokenizer(text, return_tensors="pt", truncation=True, max_length=max_input_length)
        with torch.no_grad():
            output_ids = model.generate(**inputs, max_length=max_target_length)
        summary = tokenizer.decode(output_ids[0], skip_special_tokens=True)
        summaries.append(summary)

    return summaries
