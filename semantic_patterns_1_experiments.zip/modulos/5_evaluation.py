from __future__ import annotations

from pathlib import Path
import pandas as pd


def save_reported_tables(output_dir: str | Path) -> None:
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    table1 = pd.DataFrame(
        {
            "Method": ["TF-IDF + K-means", "LDA", "BERTopic + MiniLM", "BERTopic + SciBERT"],
            "Representation": ["Lexical", "Probabilistic", "Semantic", "Scientific contextual"],
            "Coherence_cv": [0.41, 0.46, 0.54, 0.62],
            "Macro_F1": [0.68, 0.71, 0.78, 0.84],
        }
    )
    table2 = pd.DataFrame(
        {
            "Documents": [2000, 3000, 4000],
            "Coherence": [0.58, 0.61, 0.62],
            "Variation": ["±0.04", "±0.03", "±0.02"],
        }
    )
    table3 = pd.DataFrame(
        {
            "Model": ["Base Model", "Model + LoRA"],
            "ROUGE_1": [0.36, 0.41],
            "ROUGE_L": [0.31, 0.37],
            "BERTScore": [0.84, 0.88],
        }
    )
    table4 = pd.DataFrame(
        {
            "Range": [4, 8, 16],
            "ROUGE_1": [0.39, 0.41, 0.42],
            "Coherence": [0.59, 0.62, 0.62],
        }
    )

    table1.to_csv(output_dir / "table1_methods_comparison.csv", index=False)
    table2.to_csv(output_dir / "table2_stability_by_corpus_size.csv", index=False)
    table3.to_csv(output_dir / "table3_summary_performance.csv", index=False)
    table4.to_csv(output_dir / "table4_lora_rank_impact.csv", index=False)
