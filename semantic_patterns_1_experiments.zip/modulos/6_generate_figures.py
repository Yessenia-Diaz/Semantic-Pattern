from __future__ import annotations

from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd


def ensure_dir(path: str | Path) -> Path:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return p


def figure2_methods(output_dir: str | Path) -> None:
    output_dir = ensure_dir(output_dir)
    methods = ["TF-IDF +\nK-means", "LDA", "BERTopic +\nMiniLM", "BERTopic +\nSciBERT"]
    coherence = [0.41, 0.46, 0.54, 0.62]
    f1 = [0.68, 0.71, 0.78, 0.84]

    plt.figure(figsize=(9, 5))
    x = range(len(methods))
    width = 0.38
    plt.bar([i - width/2 for i in x], coherence, width=width, label="Coherence (cv)")
    plt.bar([i + width/2 for i in x], f1, width=width, label="Macro F1")
    plt.xticks(list(x), methods)
    plt.ylabel("Score")
    plt.title("Figure 2. Comparison of semantic pattern recognition methods")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_dir / "figure2_methods_comparison.png", dpi=200)
    plt.close()


def figure3_lora(output_dir: str | Path) -> None:
    output_dir = ensure_dir(output_dir)
    metrics = ["ROUGE-1", "ROUGE-L", "BERTScore"]
    base_scores = [0.36, 0.31, 0.84]
    lora_scores = [0.41, 0.37, 0.88]

    plt.figure(figsize=(8, 5))
    x = range(len(metrics))
    width = 0.38
    plt.bar([i - width/2 for i in x], base_scores, width=width, label="Base Model")
    plt.bar([i + width/2 for i in x], lora_scores, width=width, label="Model + LoRA")
    plt.xticks(list(x), metrics)
    plt.ylabel("Score")
    plt.title("Figure 3. Impact of LoRA adaptation on abstract summary quality")
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_dir / "figure3_lora_impact.png", dpi=200)
    plt.close()


def figure1_workflow(output_dir: str | Path) -> None:
    output_dir = ensure_dir(output_dir)
    steps = [
        "1. Corpus loading\n& preprocessing",
        "2. Probabilistic\ntopic modeling\n(LDA)",
        "3. Contextual\nembeddings\n(SciBERT)",
        "4. Semantic\nclustering\n(BERTopic)",
        "5. Abstractive\nsummarization\n(LoRA)",
        "6. Evaluation &\ncoherence scoring",
    ]

    plt.figure(figsize=(6, 10))
    ax = plt.gca()
    ax.axis("off")

    y = 0.93
    for i, step in enumerate(steps):
        ax.text(
            0.5, y, step, ha="center", va="center",
            bbox=dict(boxstyle="round,pad=0.4", fc="white", ec="black")
        )
        if i < len(steps) - 1:
            ax.annotate("", xy=(0.5, y - 0.08), xytext=(0.5, y - 0.03),
                        arrowprops=dict(arrowstyle="->", lw=1.5))
        y -= 0.15

    plt.title("Figure 1. Methodological framework for hybrid semantic pattern recognition", pad=20)
    plt.tight_layout()
    plt.savefig(output_dir / "figure1_workflow.png", dpi=200, bbox_inches="tight")
    plt.close()


if __name__ == "__main__":
    out = Path(__file__).resolve().parents[1] / "imagenes"
    figure1_workflow(out)
    figure2_methods(out)
    figure3_lora(out)
