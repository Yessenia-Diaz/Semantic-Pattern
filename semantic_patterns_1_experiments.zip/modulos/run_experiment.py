from __future__ import annotations

import argparse
from pathlib import Path
import yaml

from importlib.util import spec_from_file_location, module_from_spec


def load_module(module_path: Path, module_name: str):
    spec = spec_from_file_location(module_name, module_path)
    module = module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main(config_path: str) -> None:
    root = Path(__file__).resolve().parents[1]
    with open(config_path, "r", encoding="utf-8") as f:
        config = yaml.safe_load(f)

    preprocessing = load_module(root / "modulos" / "1_preprocesamiento.py", "preprocessing")
    lda_mod = load_module(root / "modulos" / "2_lda.py", "lda_mod")
    eval_mod = load_module(root / "modulos" / "5_evaluation.py", "eval_mod")
    fig_mod = load_module(root / "modulos" / "6_generate_figures.py", "fig_mod")

    dataset_path = root / config["paths"]["dataset"]
    outputs = root / config["paths"]["outputs"]
    figures = root / config["paths"]["figures"]
    outputs.mkdir(parents=True, exist_ok=True)
    (outputs / "tablas").mkdir(parents=True, exist_ok=True)
    figures.mkdir(parents=True, exist_ok=True)

    df = preprocessing.load_and_preprocess(dataset_path)
    df.to_csv(outputs / "preprocessed_dataset.csv", index=False)

    lda_run = lda_mod.run_lda(
        df["text"].tolist(),
        n_topics=config["lda"]["n_topics"],
        max_features=config["lda"]["max_features"],
    )
    lda_mod.export_topics(lda_run, outputs / "lda_topics.csv")

    eval_mod.save_reported_tables(outputs / "tablas")
    fig_mod.figure1_workflow(figures)
    fig_mod.figure2_methods(figures)
    fig_mod.figure3_lora(figures)

    summary = f"""
Experiment finished successfully.

Processed documents: {len(df)}
Saved:
- resultados/preprocessed_dataset.csv
- resultados/lda_topics.csv
- resultados/tablas/*.csv
- imagenes/*.png

Note:
BERTopic + SciBERT and LoRA modules are included as ready-to-run modules,
but were not executed automatically in this offline package because they
require downloading external model weights.
"""
    (outputs / "reportes" / "execution_summary.txt").parent.mkdir(parents=True, exist_ok=True)
    (outputs / "reportes" / "execution_summary.txt").write_text(summary.strip() + "\n", encoding="utf-8")
    print(summary.strip())


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", required=True, help="Path to YAML configuration file")
    args = parser.parse_args()
    main(args.config)
