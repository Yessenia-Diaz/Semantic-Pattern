from __future__ import annotations

from dataclasses import dataclass
from typing import List

import pandas as pd
from sklearn.decomposition import LatentDirichletAllocation
from sklearn.feature_extraction.text import CountVectorizer


@dataclass
class LDARun:
    model: LatentDirichletAllocation
    vectorizer: CountVectorizer
    topic_distributions: object
    top_words: List[List[str]]


def run_lda(texts: list[str], n_topics: int = 8, max_features: int = 3000, top_n_words: int = 10) -> LDARun:
    vectorizer = CountVectorizer(stop_words="english", max_features=max_features)
    x = vectorizer.fit_transform(texts)

    model = LatentDirichletAllocation(
        n_components=n_topics,
        random_state=42,
        learning_method="batch",
    )
    topic_distributions = model.fit_transform(x)

    vocab = vectorizer.get_feature_names_out()
    top_words = []
    for topic in model.components_:
        idx = topic.argsort()[::-1][:top_n_words]
        top_words.append(vocab[idx].tolist())

    return LDARun(model=model, vectorizer=vectorizer, topic_distributions=topic_distributions, top_words=top_words)


def export_topics(run: LDARun, output_csv: str) -> None:
    rows = [{"topic_id": i, "top_words": ", ".join(words)} for i, words in enumerate(run.top_words)]
    pd.DataFrame(rows).to_csv(output_csv, index=False)
